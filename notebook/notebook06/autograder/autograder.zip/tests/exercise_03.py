OK_FORMAT = True

test = {   'name': 'exercise_03',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import numpy as np\n>>> bool(np.isclose(x_bar, 3.5555555555555554))\nTrue',
                                       'failure_message': '"❌ The value you assigned to x_bar does not seem correct."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ The value you assigned to x_bar seems correct."\n'},
                                   {   'code': '>>> import numpy as np\n>>> bool(np.isclose(sd, 2.6837686895641673))\nTrue',
                                       'failure_message': '"❌ The value you assigned to sd does not seem correct."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ The value you assigned to sd seems correct."\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
