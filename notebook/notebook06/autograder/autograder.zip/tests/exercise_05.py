OK_FORMAT = True

test = {   'name': 'exercise_05',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> bin_widths = [p.get_width() for p in deathrate_hg.patches]\n>>> all((abs(w - 0.02) < 0.001 for w in bin_widths))\nTrue',
                                       'failure_message': '"❌ You ddi not set the binwidth to 0.02."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ You set the binwidth to 0.02."\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
