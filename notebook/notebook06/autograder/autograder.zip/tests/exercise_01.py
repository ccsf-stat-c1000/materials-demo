OK_FORMAT = True

test = {   'name': 'exercise_01',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(test_df, pd.DataFrame)\nTrue',
                                       'failure_message': '"❌ test_df is not assigned to a DataFrame."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ test_df is assigned to a DataFrame."\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
