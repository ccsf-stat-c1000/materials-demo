OK_FORMAT = True

test = {   'name': 'exercise_07',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import numpy as np\n>>> bool(np.isclose(covid_mean, 0.018474418604651165))\nTrue',
                                       'failure_message': '"❌ The value you assigned to covid_mean does not seem correct."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ The value you assigned to covid_mean seems correct."\n'},
                                   {   'code': '>>> import numpy as np\n>>> bool(np.isclose(covid_sd, 0.02043242901904577))\nTrue',
                                       'failure_message': '"❌ The value you assigned to covid_sd does not seem correct."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ The value you assigned to covid_sd seems correct."\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
