OK_FORMAT = True

test = {   'name': 'exercise_04',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(covid_df, pd.DataFrame)\nTrue',
                                       'failure_message': '"❌ covid_df is not assigned to a DataFrame."',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '"✅ covid_df is assigned to a DataFrame."\n'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
